We are using https://github.com/Box-Robotics/ros2_numpy/tree/v2.0.12-jazzy, has ros2_numpy is not yet available in the repositories. Not sub-module is being used for this repository as of 2024/2025.
